//Seleção de elementos
const alternativeForm = document.querySelector("#alternative-form");
const alternativeInput = document.querySelector("#alternative-input");
const alternativeList = document.querySelector("#alternative-list");
const editForm = document.querySelector("#edit-form");
const editInput = document.querySelector("#edit-input");
const cancelEditBtn = document.querySelector("#cancel-edit-btn");
const correta = document.getElementsByClassName(".correct-alternative")

//let oldInputValue;

//Funções

function exibirAlternativas(){
    const urlParams = new URLSearchParams(window.location.search);
    const codedid = urlParams.get('id');
    const id = decodeURIComponent(codedid);
    axios.post('http://localhost:8070/listAlternativas', {id: id}).then(response =>{
        var alternativeData = response.data
        alternativeData.forEach(alternativa => {
            saveAlternative(alternativa.conteudo)
            
        });
    }).catch((erro)=>{
        console.log(erro)
       }) 
    

}


function cadastrarAlternativa(){
    const urlParams = new URLSearchParams(window.location.search);
    const exercicioid = urlParams.get('id');
    // const decodedId = decodeURIComponent(exercicioid);
    var alternativaInput = document.getElementById('alternative-input')
    // console.log(exercicioid)

    var alternativa = {
        id:exercicioid,
        conteudo: alternativaInput.value,
        correta: 0

    }
   

    axios.post('http://localhost:8070/alternativasCreate', alternativa).then(response =>{
        console.log('criado')
    
        
    }).catch((erro)=>{
        console.log(erro)
       }) 

       location.reload()
}



const saveAlternative = (text) => {
    
    const alternative = document.createElement("div");
    alternative.classList.add("alternative");
    const alternativeTitle = document.createElement("h3");
    alternativeTitle.innerText = text;
    alternative.appendChild(alternativeTitle);

    const correctBtn = document.createElement("button")
    correctBtn.id = 'opcao-correta'
    correctBtn.classList.add("correct-alternative")
    correctBtn.innerHTML = '<i class="fa-solid fa-check"></i>'
    alternative.appendChild(correctBtn)
    
    const deleteBtn = document.createElement("button")
    deleteBtn.classList.add("remove-alternative")
    deleteBtn.innerHTML = '<i class="fa-solid fa-xmark"></i>'
    alternative.appendChild(deleteBtn)

    

    alternativeList.appendChild(alternative)
    alternativeInput.value = "";
    alternativeInput.focus();

};

const toggleForms = () => {
    // editForm.classList.toggle("hide")
    alternativeForm.classList.toggle("hide")
    alternativeList.classList.toggle("hide")
};
//Eventos
 alternativeForm.addEventListener("submit", (e) => {
    e.preventDefault();
    cadastrarAlternativa()
    
 })
 
document.addEventListener("click", (e) => {
    const targetE1 = e.target
    const parentE1 = targetE1.closest("div");
    let alternativeTitle;


    if(parentE1 && parentE1.querySelector("h3")) {
        alternativeTitle = parentE1.querySelector("h3").innerText;
    }

    if(targetE1.classList.contains("correct-alternative")) {
        parentE1.classList.toggle("correct");
    }

    if(targetE1.classList.contains("remove-alternative")) {
        parentE1.remove();
    }
    
})




