const knex = require('../database/database')

class Avisos{

//CRIAÇÃO, EDIÇÃO E DELEÇÃO
    //Criar um usuário novo 
    async new(titulo,descricao){
            await knex.insert({titulo,descricao}).table('avisos')

    }


    //Editar um usuário já existente * 
    async update(id,name,email,role){
        var user = await this.findByID(id)

        if(user !=undefined){
            var editUser ={}

            if(email!=undefined){
                if(email != user.email){
                    var result = await this.findEmail(email)
                        if(result== false){
                            editUser.email = email
                        }else{
                            return{status:false, err:'o email já está cadastrado'}
                        }
                    
                }
            }

            if(name!=undefined){
                editUser.name = name
            }

            if(role!=undefined){
                editUser.role = role
            }

            try{
                await knex.update(editUser).where({id:id}).table("users")
                return{status: true}

            }catch(err){
                return{status: false, err: err}
            }

        }else{
            return {status:false, err:"Usuario não existe"}
        }
    }


    async delete(id){
        var aviso= await this.findByID(id)
        if (aviso!=undefined){
            try{
                await knex.delete().where({id:id}).table('avisos')
                return {status: true}

            }catch(err){
                return{status:false, err: err}

            }
        }else{
            return{status: false, err: "Aviso não existe, não pode ser apagado"}
        }

    }

    

//BUSCA    
    //Listar todos os avisos
    async findAll(){
        var result = await knex.select(['id','titulo', 'descricao']).table('avisos');
        return result;
    }


    //Achar aviso pelo ID
    async findByID(id){
        var result = await knex.select(['id','titulo', 'descricao']).where({id:id}).table('avisos');
        if (result.length>0){
            return result[0]
        }else{
            return undefined
        }
    }

    //Achar aviso pelo título
    async findbyTitulo(titulo){
        var result = await knex.select(['id','titulo', 'descricao']).where({titulo:titulo}).table('avisos');
        if (result.length>0){
            return result[0]
        }else{
            return undefined
        }
    }
    

    
}

module.exports = new Avisos();
