const Avisos = require('./avisos')

class AvisosController {
    async create (req,res){
        var {titulo,descricao}=req.body
        await Avisos.new(titulo,descricao)
        
    }

    async list (req,res){
        var avisos = await Avisos.findAll()
        res.json({avisos})
    }
}

module.exports = new AvisosController;