var jwt = require('jsonwebtoken')
var secretJWT = 'jdbuefbuhfihhgeieig'


module.exports = function(req,res,next){
     const authToken = req.headers['authorization']

    if(authToken != undefined){
        const bearer = authToken.split(' ');
        var token = bearer[1];

        var decoded = jwt.verify(token,secretJWT)

        if(decoded.role == 1){
            next()
            
        }else{
            req.userData = decoded
            res.json("Você não tem permissão pra isso")
        }

        console.log(decoded)


    }else {
        res.status(403)
        res.send("Você não está autenticado")
    }

}