const express = require('express')
const app = express()
const cors = require('cors')
const bodyParser = require('body-parser')
const jwt = require('jsonwebtoken')
const UserController = require('./Users/usersController')
const AvisosController = require('./AvisosProf/avisosController')
const AdminAuth = require('./middleware/AdminAuth')
const ExerciciosController = require('./Exercicios/exerciciosController')
const ExplicacoesController = require('./Explicacoes/explicacoesController')
const CategoriasController = require('./Categorias/categoriasController')

//CONFIG
    //body-parser
app.use(bodyParser.urlencoded({extended: false}))
app.use(bodyParser.json())

    //cors
app.use(cors({
    exposedHeaders: ['Authorization'] // Aqui está a configuração para expor o cabeçalho Authorization
}))


const jwtSecret = "asjsj"


//Rotas 
app.post('/usersCreate', UserController.create)
app.post('/usersLogin', UserController.login)
app.get('/usersIndex', UserController.index)
app.get('/users/:id', UserController.findUser)
app.get('/get/:token', UserController.getToken)
app.put('/users', UserController.edit)
app.delete('/users/:id', UserController.remove)
app.post('/avisosCreate', AvisosController.create)
app.get('/avisosShow', AvisosController.list)
app.post('/exerciciosCreate',ExerciciosController.create)
app.get('/exerciciosCreate',ExerciciosController.create)
app.post('/alternativasCreate',ExerciciosController.createAlt)
app.get('/exerciciosShow', ExerciciosController.showAll)
app.get('/exerciciosShowConteudo', ExerciciosController.showAllWContent)
app.post('/exerciciosShowConteudo', ExerciciosController.showAllWContent)
app.get('/testeCategorizacao', ExerciciosController.showAllWContent)
app.post('/explicacoesCreate', ExplicacoesController.create)
app.get('/explicacoesShow', ExplicacoesController.show)
app.get('/cateoriasShow',CategoriasController.show)
app.post('/listAlternativas',ExerciciosController.exibirAlternativas)



//PORTA
app.listen(8070, ()=>{
    console.log('servidor rodando')
})