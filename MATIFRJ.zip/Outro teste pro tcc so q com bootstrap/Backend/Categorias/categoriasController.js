const Categorias = require('../Categorias/categorias')

class CategoriasController {

    async show(req,res){
        var titles = await Categorias.findAll()
        res.json(titles)
    }
}
module.exports = new CategoriasController();