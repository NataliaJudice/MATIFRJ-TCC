const knex = require('../database/database')

class Categorias {
    async findAll(){
        var resultadoCategorias = await knex.select(['id', 'nome']).table('conteudos')
        return(resultadoCategorias)
    }
}

module.exports = new Categorias();