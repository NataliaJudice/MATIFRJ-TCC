const Explicacoes = require('../Explicacoes/explicacoes')

class explicacoesController{
    async create(req,res){
        var {textoChave, titulo}= req.body
        await Explicacoes.new(textoChave, titulo)
    }

    async show(req,res){
        var titles = await Explicacoes.findTitles()
        res.json(titles)
    }
    

}
module.exports = new explicacoesController();