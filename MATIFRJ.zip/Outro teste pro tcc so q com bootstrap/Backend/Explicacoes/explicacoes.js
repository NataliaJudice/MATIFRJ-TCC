const knex = require('../database/database')

class Explicacoes{
    async new(textoChave,titulo){
    await knex.insert({textoChave,titulo}).table('explicacoes')

    }

    async findTitles(){
        var explicacoes = await knex.select(['id', 'titulo']).table('explicacoes')
        return(explicacoes)

    }
}
module.exports = new Explicacoes();