const Exercicios =  require('./exercicios')

class exerciciosController {

    async create(req,res){
       var {descricao} = req.body
       var exercicioID = await Exercicios.new(descricao)
       res.json({exercicioID})
        
        

    }

    async exibirAlternativas(req,res){
        var {id} = req.body
        
        var result = await Exercicios.exibirAlternativas(id)
        res.json(result)
    }

    async showID(req,res){
        req.body
        var id = await Exercicios.showID()
    }

    async createAlt(req,res){
        //mudar o id pra req.params quando desenvolver o front disso 
        var {conteudo,correta,id} = req.body
        await Exercicios.newAlt(id,conteudo,correta)
    }

    async showAll(req,res){
        var mostrar = await Exercicios.joinExerciciosAlternativas()
        res.json({mostrar})
        
        // var exercicios = Exercicios.findAll()
        // res.json({exercicios})
    }
    async showAllWContent(req,res){
        var {conteudo} = req.body
        var show = await Exercicios.joinConteudosExerciciosAlternativas(conteudo)
        res.json({show})
    }
}
    

module.exports = new exerciciosController();