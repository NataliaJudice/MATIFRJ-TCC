const knex = require('../database/database')

class Exercicios {

    async new(descricao,categoria){
       const [exercicioID] = await knex.insert({descricao}).table("exercicios")
       this.showID(exercicioID)
       return exercicioID;

    }

    async showID(id){
        return id

    }

    async newAlt(id,conteudo,correta){
        const [alternativaID]= await knex.insert({conteudo,correta}).table("alternativas")
        await knex.insert({exercicio_id: id, alternativa_id: alternativaID }).table('exercicios_alternativas')

    }

    async findbyID(id){
        var result = await knex.select(['id']).where({id:id}).table('exercicios');
        console.log(result)
        return result[0].id
        
        
    }

    async findAll(){
        var descricao = await knex.select(['id', 'descricao']).table('exercicios')
        console.log(descricao)
    }


    async joinExerciciosAlternativas(){
        var data = await knex.select(['exercicios.id', 'descricao', 'alternativa_id', 'conteudo', 'correta']).table('exercicios').rightJoin('exercicios_alternativas','exercicios_alternativas.exercicio_id', 'exercicios.id').rightJoin('alternativas', 'alternativas.id','exercicios_alternativas.alternativa_id')
        const exercises = {};

    data.forEach(row => {
        if (!exercises[row.id]) {
            exercises[row.id] = {
                id: row.id,
                descricao: row.descricao,
                alternativas: []
            };
        }
            exercises[row.id].alternativas.push({
                id: row.alternativa_id,
                conteudo: row.conteudo,
                correta: row.correta
            });
        
       
    });

    return Object.values(exercises);
}

async exibirAlternativas(id){
   
    var data = await knex.select(['exercicios_alternativas.exercicio_id', 'conteudo', 'alternativa_id']).table('alternativas').leftJoin('exercicios_alternativas', 'alternativas.id', 'exercicios_alternativas.alternativa_id').where({exercicio_id: id})
    return data;
}


async joinConteudosExerciciosAlternativas(conteudo){
    conteudo='soma'
    var data = await knex.select(['exercicios.id', 'descricao', 'conteudos.nome', 'alternativa_id', 'conteudo', 'correta']).table('exercicios').leftJoin('exercicios_conteudos', 'exercicios_conteudos.id_exercicio', 'exercicios.id').leftJoin('conteudos', 'conteudos.id', 'exercicios_conteudos.id_conteudo').where({nome: conteudo})
.rightJoin('exercicios_alternativas','exercicios_alternativas.exercicio_id', 'exercicios.id').rightJoin('alternativas', 'alternativas.id','exercicios_alternativas.alternativa_id')

const exercises = {};    

data.forEach(exercicio =>{
if(!exercises[exercicio.id]){
    exercises[exercicio.id]={
        id: exercicio.id,
        descricao: exercicio.descricao,
        alternativas: []
    }
}
    exercises[exercicio.id].alternativas.push({
        id: exercicio.alternativa_id,
        conteudo: exercicio.conteudo,
        correta: exercicio.correta
    })

    })

    return Object.values(exercises)
}


    


}
module.exports = new Exercicios();