const User = require('./users')
var jwt = require('jsonwebtoken')
var bcrypt = require('bcryptjs')
var secretJWT = 'jdbuefbuhfihhgeieig'

class UserController{


    async edit(req,res){
        var {id,name,email,role} = req.body
        var result = await User.update(id,name,email,role)
        if (result!=undefined){
            if(result.status){
                res.status(200)
                res.json('tudo certinhoo')
            }else{
                res.json('deu nao fi')
            }
        }
    }

    async remove(req,res){
        var id = req.params.id

        var result = await User.delete(id)

        if(result.status){
            res.json('tudo certo')
        }else{
            res.json('deu bom nao :[')
        }


    }


    
    async index(req, res){ 
        var users = await User.findAll();
        
        res.json({users})
    }


    
    async findUser(req,res){
        var id = req.params.id;
        var user = await User.findByID(id)
        if (user ==undefined){
            res.json({})
        }else{
            res.status(404)
            res.json(user)
        }
    }




    async create(req,res){
        var {email,password,name,cpf} = req.body

        if(email==undefined){
            res.status(400)
            res.json({err: 'o email é inválido'})
            return;
        }

        //Tenta encontrar o email na tabela Users com a função findEmail
        var emailExists = await User.findEmail(email);

        //Verifica se o email já existe na tabela antes de enviar os dados
        if(emailExists){
            res.status(406);
            res.json({err: "O e-mail já está cadastrado!"})
            return;//O return não permite que essa verificação seja ultrapassada, então é sempre importante lembrar
        }

        await User.new(email,password,name,cpf) //"await" garante que a operação realmente foi executada
        
        var user =  await User.findByEmail(email)
        var token = jwt.sign({email:user.email, name:user.name, role:user.role}, secretJWT)
        res.status(200)
        res.json({token:token})
        res.status(200)
        
    }


    async login(req,res){
        var {email,password} = req.body

        var user =  await User.findByEmail(email)

        if (user!=undefined){
            var result = await bcrypt.compare(password, user.password)

            if(result){
                var token = jwt.sign({email:user.email, name:user.name, role:user.role}, secretJWT)
                res.status(200)
                res.json({token:token})
            }else{
                
                res.status(404)
                res.json({err: "Usuario nao encontrado"})

            }
            
        }else{
            res.json({status: result})

        }
        
    }

    async getToken(req,res){
        var token = req.params.token
        var decoded = jwt.verify(token,secretJWT)
        var role = decoded.role
        var name = decoded.name
        
        res.json({role,name})
    }


        

}

module.exports = new UserController();