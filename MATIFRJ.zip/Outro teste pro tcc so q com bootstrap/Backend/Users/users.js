
const knex = require('../database/database')
var bcrypt = require('bcryptjs')

class User {

//CRIAÇÃO, EDIÇÃO E DELEÇÃO
    //Criar um usuário novo
    async new(email, password, name,cpf){
            var hash = await bcrypt.hash(password,10)
            await knex.insert({email, password:hash, name, role:0,cpf}).table('users')

    }


    //Editar um usuário já existente
    async update(id,name,email,role){
        var user = await this.findByID(id)

        if(user !=undefined){
            var editUser ={}

            if(email!=undefined){
                if(email != user.email){
                    var result = await this.findEmail(email)
                        if(result== false){
                            editUser.email = email
                        }else{
                            return{status:false, err:'o email já está cadastrado'}
                        }
                    
                }
            }

            if(name!=undefined){
                editUser.name = name
            }

            if(role!=undefined){
                editUser.role = role
            }

            try{
                await knex.update(editUser).where({id:id}).table("users")
                return{status: true}

            }catch(err){
                return{status: false, err: err}
            }

        }else{
            return {status:false, err:"Usuario não existe"}
        }
    }

    async delete(id){
        var user = await this.findByID(id)
        if (user!=undefined){
            try{
                await knex.delete().where({id:id}).table('users')
                return {status: true}

            }catch(err){
                return{status:false, err: err}

            }
        }else{
            return{status: false, err: "Usuario não existe, não pode ser apagado"}
        }

    }

    

//BUSCA    
    //Listar todos os usuários
    async findAll(){
        var result = await knex.select(['id','name', 'email', 'role','cpf']).table('users');
        return result;
    }


    //Achar usuário pelo ID
    async findByID(id){
        var result = await knex.select(['id','name', 'email', 'role','cpf']).where({id:id}).table('users');
        if (result.length>0){
            return result[0]
        }else{
            return undefined
        }
    }

    async findByEmail(email){
        var result = await knex.select(['id','name','password', 'email', 'role','cpf']).where({email:email}).table('users');
        if (result.length>0){
            return result[0]
        }else{
            return undefined
        }
    }

    //Achar usuário pelo Email
    async findEmail(email){
        var result = await knex.select('*').from('users').where({email:email})
        if (result.length>0){
            return true
        }else{
            return false
        }
    }

    
}

module.exports = new User();

