var knex = require('knex')({
    client: 'mysql2',
    connection: {
      host : 'localhost',
      user : 'root',
      password : 'Quincas1',
      database : 'matifrj'
    }
  });

module.exports = knex