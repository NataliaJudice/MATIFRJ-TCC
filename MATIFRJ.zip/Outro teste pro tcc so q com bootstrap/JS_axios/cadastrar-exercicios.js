function cadastrarExercicio(){

    var descricaoInput = document.getElementById('descricao')
    var descricao = {
        descricao: descricaoInput.value
    }
   

    axios.post('http://localhost:8070/exerciciosCreate', descricao).then(response =>{
        console.log('criado')
        var id = response.data.exercicioID
        console.log(id)
        
        window.location.href ='alternativas-copy.html?id='+id
    }).catch((erro)=>{
        console.log(erro)
       }) 
}

function teste(){
    axios.get('http://localhost:8070/exerciciosCreate').then(response =>{
        console.log('criado')
        var id = response.data.exercicioID
        console.log(id)
        //window.location.href ='alternativas.html?id='+id
    }).catch((erro)=>{
        console.log(erro)
       }) 

}
