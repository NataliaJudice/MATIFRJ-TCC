document.getElementById('formLogin').addEventListener('submit', function(event) {
    event.preventDefault(); // Evita o envio padrão do formulário

    var email = document.getElementById('emailL')
    var senha = document.getElementById('senhaL')
    var emailTrim = email.value.trim()
    var passwordTrim = senha.value.trim()
    


    var user = {
        email:email.value,
        password:senha.value
    } 

    if (emailTrim != "" && passwordTrim!=""){
        axios.post('http://localhost:8070/usersLogin', user).then(response =>{
            localStorage.clear()
            const token =response.data.token
            localStorage.setItem('token', token)
            //console.log('logado', token)
            axios.get('http://localhost:8070/get/'+ token).then(response=>{ 
                const role = response.data.role
                const nome= response.data.name
                console.log("esse é o" + nome)
                localStorage.setItem('role', role);
                localStorage.setItem('nome', nome); // Armazena a role no localStorage
                window.location.href = 'index.html';
                
            })      
         
        }).catch((err)=>{
            console.log(err.message)
            if(err.message == "Request failed with status code 404"){
               window.alert("Usuário não encontrado")
            }else if(err.message == "Request failed with status code 406"){
               window.alert("Senha incorreta")
            }
           }) 
           
       }else{   
           alert('Usuario Invalido')  
       }
   });

function getUserRole(){
    const role = localStorage.getItem('role');
    

    var buttonAluno = document.getElementById('enviarP')
    var buttonProf = document.getElementById('criarA')

    if(role ==1){
        window.location.href = 'index.html';
    }else if(role ==0){
        window.location.href = 'index.html';
        
    }  

}

