document.getElementById('myForm2').addEventListener('submit', function(event) {
    event.preventDefault(); // Evita o envio padrão do formulário
    var name = document.getElementById('name')
    var cpf = document.getElementById('cpf')
    var email = document.getElementById('email')
    var senha= document.getElementById('senha')
    var emailTrim = email.value.trim()
    var passwordTrim = senha.value.trim()
    


    var user = {
        name:name.value,
        email:email.value,
        password:senha.value,
        cpf:cpf.value
    } 

    if (emailTrim != "" && passwordTrim!=""){
        axios.post('http://localhost:8070/usersCreate', user).then(response =>{
            const token =response.data.token
            localStorage.setItem('token', token)
            console.log('Usuário criado')
            console.log(token)
             axios.get('http://localhost:8070/get/'+ token).then(response=>{
                const role = response.data.role
                const nome= response.data.name
                console.log("esse é o" + nome)
                localStorage.setItem('role', role);
                localStorage.setItem('nome', nome); // Armazena a role no localStorage
                window.location.href = 'index.html'
             })      
         
        }).catch((erro)=>{
         console.log('nao autorizado')
        }) 
        
    }else{   
        alert('Usuario Invalido')  
    }
});

function getUserRole(){
    const role = localStorage.getItem('role');

    var buttonAluno = document.getElementById('enviarP')
    var buttonProf = document.getElementById('criarA')

    if(role ==1){
        buttonAluno.type = "hidden"
    }else if(role ==0){
        buttonProf.type = "hidden"
    }
    
    
    

    

}