function carregarCategorias(){
    axios.get('http://localhost:8070/cateoriasShow').then(response =>{
        var select = document.getElementById('select-categoria')
        var categoriasData = response.data

        categoriasData.forEach(categoria => {
            select.innerHTML += ` 
            <option value="${categoria.id}">${categoria.nome}</option>
            `
            
        });



    })
}

